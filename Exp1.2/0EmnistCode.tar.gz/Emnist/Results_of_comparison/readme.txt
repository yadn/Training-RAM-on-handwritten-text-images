plot.py -- plots comparison between accuracies of usual approach vs fisheye approach

emnist_10x10_original_1patch.txt -- training and validation accuracies of usual approach with one 10x10 patch with 6 glimpses

emnist_10x10_original_1patch.mp4-- sample visualization result usual approach with one 10x10 patch with 6 glimpses

emnist_fisheye_2patches_10x10.txt -- training and validation accuracies of fisheye approach with one fisheye 10x10 patch with 6 glimpses

emnist_fisheye_2patches_10x10.mp4-- sample visualization result usual approach with one fisheye 10x10 patch with 6 glimpses